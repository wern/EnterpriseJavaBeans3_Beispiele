package einstein.client.gui.modell;

import java.util.Enumeration;

import einstein.client.gui.modell.status.StatusUebersetzerFactory;
import einstein.client.gui.modell.status.StatusUebersetzerInterface;
import einstein.server.oeffentlich.Partie;
import einstein.server.oeffentlich.SpielException;
import einstein.server.oeffentlich.SpielStatus;
import einstein.server.oeffentlich.SpielStatusException;

/**
 * Das Modell fuer das Spielbrett haelt die Namen der Spieler und
 * bietet Funktionalitaet zum Abfragen und Aendern des Spielstatus.
 * 
 * @author <a href="mailto:info@jessicarubart.de">Jessica Rubart</a>
 */
public class SpielbrettModell {

	protected String userA, userB, status = null;
	protected final static String leererBenutzerName = "<noch offen>";
	protected final static String computerGegnerName = "Computer";
	protected StatusUebersetzerFactory statusFactory = null;
	protected Integer tischNr = null;
	protected SpielbrettViewInterface viewInterface = null;
	
	public SpielbrettModell(SpielbrettViewInterface viewInterface) {
		statusFactory = new StatusUebersetzerFactory();
		this.viewInterface = viewInterface;
	}
	
	/**
	 * Setzt die Spielernamen und den Spielstatus.
	 * 
	 * @return aktuelle Partie
	 * @throws SpielStatusException
	 */
	public Partie update() throws SpielStatusException {
		Partie partie = null;
		try {
			partie = EJBZugriff.partieAbfragen();
		} catch (SpielException ex) {
			userA = ueberpruefeBenutzerName(null);
			userB = ueberpruefeBenutzerName(null);
			status = null;
			return null;
		}
		
		userA = partie.getSpielerA();
		if (! partie.isComputerGegner()) {
			userB = partie.getSpielerB();
		} else {
			userB = computerGegnerName;
		}
		userA = ueberpruefeBenutzerName(userA);
		userB = ueberpruefeBenutzerName(userB);
		setStatus(partie.getStatus().toString());
		
		return partie;
	}
	
	/**
	 * Falls der uebergebene Name null ist, wird dieser auf 
	 * SpielbrettModell.leererBenutzerName gesetzt.
	 * 
	 * @param name
	 * @return Benutzername
	 */
	protected String ueberpruefeBenutzerName(String name) {
		if (name == null) {
			name = leererBenutzerName;
		}
		return name;
	}
	
	public String getUserA() {
		return this.userA;
	}
	
	public String getUserB() {
		return this.userB;
	}
	
	public String getStatus() {
		return this.status;
	}
	
	public void setStatus(String status) {
		this.status = status;
	}
	
	/**
	 * Liefert eine fachliche Beschreibung des Status.
	 * Falls keine Uebersetzung gefunden wird, wird die
	 * technische Beschreibung zurueckgegeben.
	 * 
	 * @return Status-Beschreibung
	 */
	public String getUebersetztenStatus() {
		String status = null;
		for (Enumeration e = statusFactory.getUebersetzer().elements(); e.hasMoreElements();) {
			status = ((StatusUebersetzerInterface)e.nextElement()).uebersetzeStatus(this);
			if (status != null) {
				return status;
			}
		}
		return getStatus();
	}
	
	/**
	 * Liefert true, wenn ein weiterer Spieler gesucht wird,
	 * andernfalls false.
	 * 
	 * @param partie
	 * @return true, wenn ein weiterer Spieler gesucht wird, andernfalls false.
	 */
	public boolean spielerGesucht(Partie partie) {
		// im Falle einer Partie gegen den Computer wird kein weiterer Spieler gesucht
		if (!partie.isComputerGegner()) {
			return ( userA.equals(leererBenutzerName) || userB.equals(leererBenutzerName) );
		}
		return false;
	}
	
	/**
	 * Liefert true, wenn der mit diesem Client angemeldete Benutzer kein Spieler ist,
	 * andernfalls false.
	 * 
	 * @return true, wenn der mit diesem Client angemeldete Benutzer kein Spieler ist, andernfalls false.
	 */
	public boolean benutzerIstKeinSpieler() {
		return ((!userA.equals(LoginModell.getBenutzerName())) && (!userB.equals(LoginModell.getBenutzerName())));
	}
	
	/**
	 * Liefert true, wenn der mit diesem Client angemeldete Benutzer Spieler, aber noch nicht bereit, ist.
	 * Andernfalls wird false zurueckgegeben.
	 * 
	 * @param partie
	 * @return true, wenn der mit diesem Client angemeldete Benutzer Spieler, aber noch nicht bereit, ist.
	 */
	public boolean benutzerIstNochNichtBereit(Partie partie) {
		return ( partie.getStatus().equals(SpielStatus.KEIN_SPIEL) || 
				((userA.equals(LoginModell.getBenutzerName())) && partie.getStatus().equals(SpielStatus.B_BEREIT)) ||
				((userB.equals(LoginModell.getBenutzerName())) && partie.getStatus().equals(SpielStatus.A_BEREIT)) ||
				(spielVorbei(partie)) );
	}
	
	/**
	 * Liefert true, wenn die Partie vorbei ist, d.h. einer der Gegner im Status abgebrochen
	 * oder gewonnen.
	 * Andernfalls wird false zurueckgegeben.
	 * 
	 * @param partie
	 * @return true, wenn die Partie vorbei ist, d.h. einer der Gegner im Status abgebrochen oder gewonnen.
	 */
	public boolean spielVorbei(Partie partie) {
		return ( partie.getStatus().equals(SpielStatus.A_ABGEBROCHEN) ||
				 partie.getStatus().equals(SpielStatus.B_ABGEBROCHEN) ||
				 partie.getStatus().equals(SpielStatus.A_GEWONNEN) ||
				 partie.getStatus().equals(SpielStatus.B_GEWONNEN));
	}
	
	/**
	 * Der aktuelle Benutzer wird als Spieler an den aktuellen Tisch
	 * gesetzt.
	 */
	public void einsteigen() {
		try {
			EJBZugriff.einsteigen(EJBZugriff.getAktuellerTisch());
		} catch (SpielException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Hiermit wird fuer die aktuelle Spielerin gemeldet, dass sie bereit ist,
	 * das Spiel zu starten.
	 */
	public void bereit() {
		try {
			EJBZugriff.bereit();
		} catch (SpielException e) {
			viewInterface.falschesSpiel(e);
		} catch (SpielStatusException e) {
			viewInterface.falscherStatus(e);
		}
	}
	
	/**
	 * Der aktuelle Benutzer verlaesst den aktuellen Tisch.
	 */
	public void verlassen() {
		try {
			EJBZugriff.aktuellenTischVerlassen();
		} catch (SpielException e) {
			viewInterface.falschesSpiel(e);
		} 
	}

}
