package einstein.client.gui.swing;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Enumeration;
import java.util.Hashtable;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import einstein.client.gui.modell.SpielbrettModell;
import einstein.client.gui.modell.SpielbrettViewInterface;
import einstein.server.oeffentlich.Partie;
import einstein.server.oeffentlich.Position;
import einstein.server.oeffentlich.SpielException;
import einstein.server.oeffentlich.SpielStatus;
import einstein.server.oeffentlich.SpielStatusException;
import einstein.server.oeffentlich.Stein;

/**
 * Beschreibt das Spielbrett, die Steuerungsschaltflaechen und die Statuszeile
 * und unterstuetzt deren Aktualisierung. 
 * 
 * @author <a href="mailto:info@jessicarubart.de">Jessica Rubart</a>
 */
public class Spielbrett extends JPanel implements ActionListener, SpielbrettViewInterface {
	private static final long serialVersionUID = 1L;
	protected SpielbrettModell modell = null;
	protected Hashtable<String, Feld> fields = null;
	protected Hashtable<Integer, ImageIcon> iconsRed = null;
	protected Hashtable<Integer, ImageIcon> iconsYellow = null;
	protected JPanel spielbrettPanel = null;
	protected JLabel labelStatus = null;
	protected static JLabel labelTisch = null;
	protected Wuerfel diceA, diceB = null;
	protected JPanel aktivierungsLeiste = null;
	protected JButton bereitB, verlassenB = null;
	protected final static String tischUeberschrift = "Tisch";
	protected static String tischNr = "X";
	protected final static String leererTischUeberschrift = "Leerer Tisch";
	
	public interface AktionsSchluessel {
        public final static String VERLASSEN = "Tisch verlassen",
                                   BEREIT = "Bereit";
    }

	/**
	 * Initialisiert das Spielbrett.
	 */
	public Spielbrett() {
		super(new BorderLayout());
		this.modell = new SpielbrettModell(this);
		
		JPanel innen = new JPanel(new BorderLayout());
		
		innen.add(initialisiereInfoBereich(), BorderLayout.NORTH);
		innen.add(initialisiereFelderUndWuerfel(), BorderLayout.CENTER);
		innen.add(initialisiereSteuerungsBereich(), BorderLayout.SOUTH);
		
		innen.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
		this.add(innen, BorderLayout.CENTER);
		this.setBackground(Color.LIGHT_GRAY);
	}
	
	public Insets getInsets() {
		return new Insets(10, 10, 10, 10);
	}
	
	public Dimension getPreferredSize() {
		return new Dimension(600, 530);
	}
	
	public static void updateTischNr(String tischNr) {
		Spielbrett.tischNr = tischNr;
		if (labelTisch != null) {
			labelTisch.setText(tischUeberschrift + " " + tischNr);
		}
	}
	
	protected static void erzeugeTischBeschriftung() {
		if (labelTisch == null) {
			labelTisch = new JLabel(tischUeberschrift + " " + tischNr);
			labelTisch.setFont(new java.awt.Font("Arial", 1, 14));
		}
	}
	
	/**
	 * Initialisiert den Ueberschrift- und Statusbereich.
	 * 
	 * @return zugehoeriges Panel
	 */
	protected JPanel initialisiereInfoBereich() {
		JPanel info = new JPanel() {
			private static final long serialVersionUID = 1L;
			public Insets getInsets() {
	        	return new Insets(10, 10, 20, 10);
	        }
	      };
	    info.setBackground(Color.LIGHT_GRAY);
		info.setLayout(new FlowLayout(FlowLayout.LEFT));
		erzeugeTischBeschriftung();
		labelStatus = new JLabel(leererTischUeberschrift);
		JPanel statusPanel = new JPanel(new BorderLayout()){
			private static final long serialVersionUID = 1L;
			public Insets getInsets() {
        		return new Insets(0, 20, 0, 0);
        	}
		}; 
		statusPanel.add(labelStatus, BorderLayout.CENTER); 
		statusPanel.setBackground(Color.LIGHT_GRAY);
		labelStatus.setFont(new java.awt.Font("Arial", 1, 14));
		info.add(labelTisch); 
		info.add(statusPanel);
		return info;
	}
	
	/**
	 * Initialisiert den Steuerungsbereich (Buttons)
	 * 
	 * @return zugehoeriges Panel
	 */
	protected JPanel initialisiereSteuerungsBereich() {
		final FlowLayout fl = new FlowLayout(FlowLayout.LEFT);
		aktivierungsLeiste = new JPanel(){
			private static final long serialVersionUID = 1L;
			public Insets getInsets() {
				return new Insets(0, diceA.getWidth() - fl.getHgap(), 0, 0);
			};
		};
		aktivierungsLeiste.setLayout(fl);
		
		aktivierungsLeiste.setBackground(Color.LIGHT_GRAY);
		bereitB = new JButton(AktionsSchluessel.BEREIT);
		bereitB.setEnabled(false);
		bereitB.addActionListener(this);
		aktivierungsLeiste.add(bereitB);
		verlassenB = new JButton(AktionsSchluessel.VERLASSEN);
		verlassenB.addActionListener(this);
		verlassenB.setEnabled(false);
		aktivierungsLeiste.add(verlassenB);
		return aktivierungsLeiste;
	}
	
	/**
	 * Initialisiert die Felder des Spielbretts und die Wuerfel.
	 * 
	 * @return zugehoeriges Panel
	 */
	protected JPanel initialisiereFelderUndWuerfel() {
		spielbrettPanel = new JPanel();
		spielbrettPanel.setBackground(Color.LIGHT_GRAY);
		spielbrettPanel.setLayout(new GridLayout(0, 7));
		fields = new Hashtable<String, Feld>();
		iconsRed = new Hashtable<Integer, ImageIcon>();
		iconsYellow = new Hashtable<Integer, ImageIcon>();
		for (int i = 1; i < 7; i++) {
			iconsRed.put(new Integer(i), new ImageIcon(this.getClass().getClassLoader().getResource("einstein/client/gui/icons/Piece-Red-" + i + ".gif")));
			iconsYellow.put(new Integer(i), new ImageIcon(this.getClass().getClassLoader().getResource("einstein/client/gui/icons/Piece-Yellow-" + i + ".gif")));
		}
		
		diceA = new Wuerfel(this, true);
		spielbrettPanel.add(diceA);
		for (int i = 1; i < 6; i++) {
			if (i%2!=0) {
				erzeugeZeile(Color.GRAY, Color.WHITE, i);
			} else {
				erzeugeZeile(Color.WHITE, Color.GRAY, i);
			}
		}
		diceB = new Wuerfel(this, false);
		spielbrettPanel.add(diceB);
		
		return spielbrettPanel;
	}
	
	/**
	 * Erzeugt eine Zeile mit Feldern des Spielbretts.
	 * 
	 * @param color1
	 * @param color2
	 * @param line
	 */
	protected void erzeugeZeile (Color color1, Color color2, int line) {	
		if (line > 1) {
			spielbrettPanel.add(new Feld(Color.LIGHT_GRAY, uebersetzePosition(new Position(0, line))));
		}
		
		int column = 0;
		for (int i = 1; i < 3; i++) {
			column = erzeugeInneresFeld(color1, column, line);
			column = erzeugeInneresFeld(color2, column, line);
		}
		Position pos = uebersetzePosition(new Position(5, line));
		Feld currentField = new Feld(color1, pos);
		spielbrettPanel.add(currentField);
		fields.put(pos.toString(), currentField);
		if (line < 5) {
			spielbrettPanel.add(new Feld(Color.LIGHT_GRAY, uebersetzePosition(new Position(6, line))));
		}
	}
	
	protected int erzeugeInneresFeld(Color color, int column, int line){
		column++;
		Position pos = uebersetzePosition(new Position(column, line));
		Feld currentField = new Feld(color, pos);
		spielbrettPanel.add(currentField); 
		fields.put(pos.toString(), currentField);
		return column;
	}
	
	/**
	 * Zeigt das Spielbrett als leeren Tisch an.
	 */
	protected void leererTisch() {
		updateTischNr(Spielbrett.tischNr);
		labelStatus.setText(leererTischUeberschrift);
		bereitB.setEnabled(false);
		verlassenB.setEnabled(false);
		diceA.setCount(0);
		diceB.setCount(0);
		diceA.setSpielerName(modell.getUserA());
		diceB.setSpielerName(modell.getUserB());
		
		JPanel feld = null;
		for (int i = 0; i < spielbrettPanel.getComponentCount(); i++) {
			feld = (JPanel)spielbrettPanel.getComponent(i);
			if (feld instanceof Feld) {
				((Feld)feld).loescheStein();
			}
		}
		
		validate();
		repaint();
	}
	
	protected Position uebersetzePosition(Position pos) {
		pos.y = 5 - pos.y + 1;
		return pos;
	}
	
	public SpielbrettModell getModell() {
		return this.modell;
	}
	
	/**
	 * Aktualisiert das Spielbrett abhaengig vom Status des Servers.
	 * 
	 * @throws SpielStatusException
	 */
	public void update() throws SpielStatusException {
		Partie partie = modell.update();
		if (partie == null) {
			this.leererTisch();
			return;
		}
		// update buttons	
		updateButtons(partie);	
		// update Felder
		updateFelder(partie);
		// update Statuszeile
		labelStatus.setText(modell.getUebersetztenStatus());
		// update Wuerfel
		
		if (partie.getStatus().equals(SpielStatus.A_AM_ZUG)) {
			diceA.setCount(partie.getStand().getZuletztGewuerfelt());
		} else if (partie.isComputerGegner() && (!partie.getStatus().equals(SpielStatus.KEIN_SPIEL))) {
			diceB.setCount(partie.getStand().getZuletztGewuerfelt());
		}	
			
		if (partie.getStatus().equals(SpielStatus.A_WUERFELT)) {
			diceA.setCount(0);
		} else if (partie.getStatus().equals(SpielStatus.B_AM_ZUG)) {
			diceB.setCount(partie.getStand().getZuletztGewuerfelt());	
		} else if (partie.getStatus().equals(SpielStatus.B_WUERFELT)) {
			diceB.setCount(0);
		} else if (partie.getStatus().equals(SpielStatus.KEIN_SPIEL) || partie.getStatus().equals(SpielStatus.A_BEREIT) 
				   || partie.getStatus().equals(SpielStatus.B_BEREIT)) {
			diceA.setCount(0);
			diceB.setCount(0);
		} 
		diceA.setSpielerName(modell.getUserA());
		diceB.setSpielerName(modell.getUserB());
		
		validate();
		repaint();
		
		// update dragging
		for (Enumeration e = fields.elements(); e.hasMoreElements();) {
			((Feld)e.nextElement()).update();
		}
	}
	
	/**
	 * Aktualisiert die Steuerung (Buttons).
	 * 
	 * @param partie
	 */
	protected void updateButtons(Partie partie) {
		if (!verlassenB.isEnabled()) {
			verlassenB.setEnabled(true);
		}
		
		boolean bereit = false;
		if (!modell.spielerGesucht(partie)) {
			if (!modell.benutzerIstKeinSpieler()) {
				if (modell.benutzerIstNochNichtBereit(partie)) {
					bereit = true;
				} 
			}
		}
		
		if (bereit) {
			bereitB.setEnabled(true);
		} else {
			bereitB.setEnabled(false);
		}
	}
	
	/**
	 * Aktualisiert die Felder des Spielbretts.
	 * 
	 * @param partie
	 */
	protected void updateFelder(Partie partie) {
		for (Enumeration e = fields.elements(); e.hasMoreElements();) {
			((Feld)e.nextElement()).removeAll();
		}
		Feld currentField = null;
		for (Stein stein : partie.getAufstellung()) {
	        currentField = fields.get(stein.position.toString());
	        if (currentField != null) {
	        	ImageIcon icon = null;
	        	if (stein.spielerA) {
	        		icon = iconsRed.get(new Integer(stein.nr));
	        	} else {
	        		icon = iconsYellow.get(new Integer(stein.nr));
	        	}
	        	currentField.addStein(icon, stein.nr, stein.id);
	        }        
	    }
	}
	
	public void falschesSpiel(SpielException e) {
		JOptionPane.showMessageDialog(this, e.getMessage(), "Falsches Spiel", JOptionPane.INFORMATION_MESSAGE);
	}
	
	public void falscherStatus(SpielStatusException e) {
		JOptionPane.showMessageDialog(this, e.getMessage(), "Falscher Status", JOptionPane.INFORMATION_MESSAGE);
	}
	
	public void actionPerformed(ActionEvent event) {
		if (event.getActionCommand().equals(AktionsSchluessel.BEREIT)) {
			modell.bereit();
		}  else if (event.getActionCommand().equals(AktionsSchluessel.VERLASSEN)) {
			modell.verlassen();
		} 
	}

}
